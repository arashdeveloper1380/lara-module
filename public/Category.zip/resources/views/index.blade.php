@extends('master')

@section('content')
    <h2>Category</h2>
    
    {{ $isEnable }}
@endsection